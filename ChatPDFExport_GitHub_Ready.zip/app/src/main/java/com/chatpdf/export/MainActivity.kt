package com.chatpdf.export

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var editor: EditText
    private val saveCode = 101
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 28, 22, 20) }
        layout.addView(TextView(this).apply { text = "ChatPDF Export"; textSize = 24f; setTextColor(Color.BLACK) })
        layout.addView(TextView(this).apply { text = "Вставьте ответ ChatGPT или отправьте его через «Поделиться». PDF создаётся без интернета."; textSize = 14f })
        editor = EditText(this).apply { hint = "Текст или Markdown…"; gravity = 48; minLines = 12; setTextIsSelectable(true) }
        layout.addView(editor, LinearLayout.LayoutParams(-1, 0, 1f))
        val paste = Button(this).apply { text = "Вставить из буфера"; setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            editor.setText(clipboard.primaryClip?.getItemAt(0)?.coerceToText(this@MainActivity) ?: "")
        } }
        layout.addView(paste)
        layout.addView(Button(this).apply { text = "Создать PDF"; setOnClickListener {
            if (editor.text.isBlank()) Toast.makeText(this@MainActivity, "Сначала вставьте текст", Toast.LENGTH_SHORT).show()
            else startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"; putExtra(Intent.EXTRA_TITLE, "ChatGPT_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())}.pdf") }, saveCode)
        } })
        setContentView(layout)
        if (intent?.action == Intent.ACTION_SEND) editor.setText(intent.getStringExtra(Intent.EXTRA_TEXT) ?: "")
    }
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == saveCode && resultCode == RESULT_OK && data?.data != null) {
            try { contentResolver.openOutputStream(data.data!!)?.use { exportPdf(it, editor.text.toString()) }; Toast.makeText(this, "PDF сохранён", Toast.LENGTH_LONG).show() }
            catch (e: Exception) { Toast.makeText(this, "Ошибка: ${e.message}", Toast.LENGTH_LONG).show() }
        }
    }
    private fun exportPdf(out: java.io.OutputStream, source: String) {
        val doc = PdfDocument()
        val width = 595; val height = 842; val left = 48f; val right = 547f; val bottom = 795f
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; textSize = 11.5f; typeface = Typeface.create("sans-serif", Typeface.NORMAL) }
        var pageNumber = 0; var y = 52f; var page: PdfDocument.Page? = null
        fun newPage() { page?.let { doc.finishPage(it) }; pageNumber++; page = doc.startPage(PdfDocument.PageInfo.Builder(width, height, pageNumber).create()); y = 52f }
        fun line(text: String, size: Float, bold: Boolean, extra: Float = 0f) {
            if (page == null || y + size + 8 > bottom) newPage()
            paint.textSize = size; paint.typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
            page!!.canvas.drawText(text, left, y, paint); y += size * 1.48f + extra
        }
        fun wrapped(raw: String, size: Float, bold: Boolean, extra: Float = 0f) {
            paint.textSize = size; paint.typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
            val words = raw.split(Regex("\\s+")); var current = ""
            for (word in words) {
                val test = if (current.isEmpty()) word else "$current $word"
                if (paint.measureText(test) > right - left && current.isNotEmpty()) { line(current, size, bold); current = word }
                else current = test
                while (paint.measureText(current) > right-left && current.length > 1) {
                    var i = current.length - 1
                    while (i > 1 && paint.measureText(current.substring(0,i)) > right-left) i--
                    line(current.substring(0,i),size,bold); current = current.substring(i)
                }
            }
            if (current.isNotEmpty()) line(current,size,bold,extra)
        }
        newPage()
        for (original in source.replace("\r\n", "\n").lines()) {
            val s = original.trim()
            if (s.isEmpty()) { y += 7f; continue }
            val hashes = s.takeWhile { it == '#' }.length
            val text = s.replace(Regex("^(#{1,6}\\s+|[-*]\\s+|\\d+\\.\\s+)"), "").replace("**", "").replace("__", "").replace("`", "")
            val bullet = if (s.matches(Regex("^([-*]|\\d+\\.)\\s+.*"))) "• " else ""
            val size = when { hashes == 1 -> 19f; hashes == 2 -> 16f; hashes in 3..6 -> 13f; else -> 11.5f }
            wrapped(bullet + text, size, hashes > 0, if (hashes > 0) 5f else 0f)
        }
        page?.let { doc.finishPage(it) }
        doc.writeTo(out); doc.close()
    }
}
